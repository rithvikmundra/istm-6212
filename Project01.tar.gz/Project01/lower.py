#!/usr/bin/env python

"""
A filter that converts upper case to lower case.
"""

import fileinput


def process(line):
    """For each line of input, convert the text to lowecrase."""
    line=line.strip()
    line_lower=line.lower() 
    print (line_lower)

for line in fileinput.input():
	process(line)
	
