#!/usr/bin/env python

"""
A filter that splits lines of text into one words.
"""

import fileinput
import re

def process(line):
    """For each line of input, split the lines of text into words."""
    data = re.compile('\w+')
    line = data.findall(line)
    
    for i in line:
        if len(i) >=2:
            print (i)        

for line in fileinput.input():
	process(line)

